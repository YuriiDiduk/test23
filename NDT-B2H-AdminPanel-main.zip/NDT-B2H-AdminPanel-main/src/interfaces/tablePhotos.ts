export interface IPhotoList {
  id: string;
  photo: string;
}