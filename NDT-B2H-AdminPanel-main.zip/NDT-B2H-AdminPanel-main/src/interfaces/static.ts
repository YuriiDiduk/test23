export interface IStatic {
  id: number;
  title: string;
}
