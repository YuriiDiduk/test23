export const VAPID_KEY =
  "BAW5guMKjN2cJ-YlRyYaT_pgjIZiygePA5k8FWmj6FfPXowp-IrkJmGAwP_Ak8_A4NPBeJcpLnSqGCj_7MByCvk";
