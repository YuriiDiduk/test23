export const chartsColors = {
  ethnicity: ["#278B6F", "#32B38E", "#60D2B1", "#8ADEC6", "#AFE8D8"],
  age: ["#5fa1f9", "#0045A3", "#182C47", "#A0BBDF", "#4076BF"],
};