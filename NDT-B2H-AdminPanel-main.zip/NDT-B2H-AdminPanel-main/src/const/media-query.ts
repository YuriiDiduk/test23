export const MOBILE_QUERY = "(max-width: 1024px)";
export const DESKTOP_QUERY = "(min-width: 1600px)";