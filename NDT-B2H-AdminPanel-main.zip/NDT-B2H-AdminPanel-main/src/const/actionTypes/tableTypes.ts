import { makeActionType } from "helpers";

export const GET_TABLE_PHOTO = makeActionType("GET_TABLE_PHOTO");
export const RESET_TABLE_PHOTOS = "RESET_TABLE_PHOTOS";
export const RESET_TABLE = "RESET_TABLE";

